<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ImportUser;
use App\Exports\ExportUser;
use App\Models\User;


class UserController extends Controller
{
    public function importView(Request $request)
    {
        return view('importFile');
    }

    public function import(Request $request)
    {
        if (empty($request->file('file'))) {
            return back()->with('error', 'Please upload a file');
        } else {
            Excel::import(new ImportUser, $request->file('file')->store('files'));
            return redirect()->back()->with('success', 'File uploaded successfully!');
        }
    }

    public function exportUsers(Request $request)
    {
        return Excel::download(new ExportUser, 'users.xlsx');
    }
}
